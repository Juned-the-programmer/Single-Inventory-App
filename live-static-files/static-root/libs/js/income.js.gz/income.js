$(document).ready(function(){
    // $('.customername').on("change",function(){
    //     alert("Hello");
    // });
    alert("Hello");
});
